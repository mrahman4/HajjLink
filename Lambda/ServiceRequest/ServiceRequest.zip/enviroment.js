const enviroment = {

    DB_HOST: 'generalinstance.cnd8wcosjatd.us-east-1.rds.amazonaws.com',
    DB_USER: 'generalUser',
    DB_PSWD: 'User_1235',
    DB_SCHEMA: 'general_schema'

};
module.exports = enviroment;
