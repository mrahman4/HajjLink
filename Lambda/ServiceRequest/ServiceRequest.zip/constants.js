const constants = {

  //function return code
  SUCCESS_RESPONSE: 200,
  ERROR_RESPONSE: 400

};
module.exports = constants;
